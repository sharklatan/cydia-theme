rm -rf Packages.bz2
bzip2 -k -z Packages